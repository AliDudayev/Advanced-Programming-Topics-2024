package fact.it.achievements;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AchievementsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AchievementsApplication.class, args);
	}

}
